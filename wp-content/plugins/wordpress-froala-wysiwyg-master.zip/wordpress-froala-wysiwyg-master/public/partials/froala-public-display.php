<?php

/**
 * Provide a public-facing view for the plugin
 *
 *
 * @link       www.froala.com
 * @since      1.0.0
 *
 * @package    Froala
 * @subpackage Froala/public/partials
 */
?>

