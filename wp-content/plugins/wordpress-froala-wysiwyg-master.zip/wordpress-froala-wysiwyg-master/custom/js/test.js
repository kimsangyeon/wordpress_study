console.log('%c Froala is awesome!', 'background: blue; color: white; display: block; line-height: 40px;');
console.log('%c This is a test file that can be deleted at any time.', 'background: gray; color: white; display: block; line-height: 40px;');
